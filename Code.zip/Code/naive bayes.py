#!/usr/bin/env python
# coding: utf-8

# In[5]:


import pandas as pd 
import numpy as np 
import matplotlib.pyplot as plt 


#Importing data
train=pd.read_csv("C:/Users/userr/Downloads/data science/Data/TRAINING.csv")
test=pd.read_csv("C:/Users/userr/Downloads/data science/Data/FEATURE.csv")

#show head 
train.head(10)
test.head(10)

#show tail
train.tail(10)
test.tail(10)




# In[11]:


from sklearn.metrics import mean_squared_error
from math import sqrt

dd= np.asarray(train.Total_Case)
y_hat = test.copy()
y_hat['naive'] = dd[len(dd)-1]

plt.figure(figsize=(12,8))
plt.plot(train.index, train['Total_Case'], label='Train')
plt.plot(test.index,test['Total_Case'], label='Test')
plt.plot(y_hat.index,y_hat['naive'], label='Naive Forecast')
plt.legend(loc='best')
plt.title("Naive Forecast")
plt.show()


# In[9]:


rms = sqrt(mean_squared_error(test.Total_Case, y_hat.naive))
print("Mean squared error: %.2f" %rms)


# In[10]:


#Plotting data
train.Total_Case.plot(figsize=(15,8), title= 'Total Case', fontsize=14)
test.Total_Case.plot(figsize=(15,8), title= 'Total Case', fontsize=14)
plt.show()


# In[ ]:


#Aggregating the dataset at daily level
train.Timestamp = pd.to_datetime(train.,format='%d-%m-%Y %H:%M') 
train.index = train.Timestamp 
train = train.resample('D').mean() 
test.Timestamp = pd.to_datetime(test.Datetime,format='%d-%m-%Y %H:%M') 
test.index = test.Timestamp 
test = test.resample('D').mean()

