#!/usr/bin/env python
# coding: utf-8

# In[1]:





# In[8]:


data = pd.read_csv('2010_.csv')


# In[9]:


import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib
from matplotlib import pyplot as plt


# In[10]:


data = pd.read_csv('2010_.csv')


# In[11]:


data.head()


# In[14]:


#Importing data
df = pd.read_csv('training.csv')
#Printing head
df.head()


# In[15]:


#Printing tail
df.tail()


# In[19]:


# Importing the libraries
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd


# In[20]:


# Importing the dataset
training = pd.read_csv('TRAINING.csv',index_col='Week Start Date',parse_dates=True)
testing = pd.read_csv('FEATURE.csv',index_col='Week Start Date',parse_dates=True)


# In[22]:


from statsmodels.tsa.api import ExponentialSmoothing, SimpleExpSmoothing, Holt


# In[23]:


import statsmodels.api as sm


# In[24]:


y_hat_avg1 = testing.copy()
fit11 = ExponentialSmoothing(np.asarray(training['Total_Case']) ,seasonal_periods=7 ,trend='add', seasonal='add',).fit()
y_hat_avg1['Holt_Winter'] = fit11.forecast(len(testing))
plt.figure(figsize=(16,8))
plt.plot( training['Total_Case'], label='Train')
plt.plot(testing['Total_Case'], label='Test')
plt.plot(y_hat_avg1['Holt_Winter'], label='Holt_Winter')
plt.legend(loc='best')
plt.show()


# In[25]:


from sklearn.metrics import mean_squared_error
from math import sqrt
rms = sqrt(mean_squared_error(testing.Total_Case, y_hat_avg1.Holt_Winter))
print(rms)


# In[ ]:





# In[1]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:




